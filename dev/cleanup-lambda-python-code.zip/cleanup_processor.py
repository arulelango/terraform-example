def lambda_handler(event, context):
    print("Cleanup lambda function")