def lambda_handler(event, context):
    print("DB lambda function")