def lambda_handler(event, context):
    print("GBG lambda function")