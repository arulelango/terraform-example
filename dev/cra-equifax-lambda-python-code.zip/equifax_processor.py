def lambda_handler(event, context):
    print("Equifax lambda function")